CREATE TRIGGER `update_bill_acceptor`
BEFORE UPDATE ON `bill_acceptor`
FOR EACH ROW
  BEGIN
                    IF (OLD.status = 1 && NEW.status = 2) THEN
                        BEGIN
                            SET NEW.sum = 0;
                        END;
                    END IF;
                END