CREATE TRIGGER `insert_bills`
BEFORE INSERT ON `bills`
FOR EACH ROW
  BEGIN
                    SET NEW.date = UNIX_TIMESTAMP();
                END