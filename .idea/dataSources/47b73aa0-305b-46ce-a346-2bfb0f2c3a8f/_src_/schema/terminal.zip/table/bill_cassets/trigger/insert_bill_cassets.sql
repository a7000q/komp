CREATE TRIGGER `insert_bill_cassets`
BEFORE INSERT ON `bill_cassets`
FOR EACH ROW
  BEGIN
                    SET NEW.date_start = UNIX_TIMESTAMP();
                END