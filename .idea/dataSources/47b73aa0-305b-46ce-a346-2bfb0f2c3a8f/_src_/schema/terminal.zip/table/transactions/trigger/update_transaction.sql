CREATE TRIGGER `update_transaction`
BEFORE UPDATE ON `transactions`
FOR EACH ROW
  BEGIN
                    SET NEW.sum = NEW.volume * NEW.price;

                END