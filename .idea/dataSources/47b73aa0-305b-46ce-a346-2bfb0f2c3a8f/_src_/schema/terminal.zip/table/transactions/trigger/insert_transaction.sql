CREATE TRIGGER `insert_transaction`
BEFORE INSERT ON `transactions`
FOR EACH ROW
  BEGIN
                    SET NEW.date = UNIX_TIMESTAMP();
                    
                    IF NEW.id_type = 1 THEN
                        BEGIN
                            SET @id_product := (SELECT `id_product` FROM `trk_address` WHERE `id` = new.id_trk_address);
                            SET @price := (SELECT `price` FROM `products` WHERE `id` = @id_product);
                            SET NEW.price = @price;
                        END;
                    END IF;
                        
                END