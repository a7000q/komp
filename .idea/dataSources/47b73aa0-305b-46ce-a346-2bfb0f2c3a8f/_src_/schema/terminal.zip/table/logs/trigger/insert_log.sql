CREATE TRIGGER `insert_log`
BEFORE INSERT ON `logs`
FOR EACH ROW
  BEGIN
                    SET NEW.date = UNIX_TIMESTAMP();
                END